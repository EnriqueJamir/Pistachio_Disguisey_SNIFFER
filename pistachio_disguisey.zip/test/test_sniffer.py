# Script Python de teste simulando envio e recebimento de pacotes
print("Simulação de pacote enviada e log gravado")