# Pistachio Disguisey

**Projeto:** Sniffer USB para captura de transações com registro seguro e transparência.

**Descrição:**
O Pistachio Disguisey é um sniffer USB projetado para capturar transações, adicionar timestamp, criptografar os dados e gravar em buffer sem interferir na comunicação original. Ele consiste em múltiplos módulos, sendo o Módulo 1 responsável pela captura e logging das transações.

**Estrutura do Projeto:**
- `docs/`: Documentação detalhada por módulo.
- `src/`: Código fonte C++ para microcontrolador.
- `test/`: Scripts Python para testar captura e logs.
- `logs/`: Logs gerados pelo sniffer.

**Requisitos:**
- Microcontrolador com suporte a C++ e USB.
- Bibliotecas AES compatíveis.
- Sistema de tempo (RTC) ou POS timestamp.

**Autor:** HACX