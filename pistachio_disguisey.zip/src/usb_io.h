#pragma once
#include <string>
struct Packet { bool exists(); };
struct Transaction { std::string data; std::string timestamp; };
class USBDevice {
public:
    Packet readPacket();
    void sendPacket(const Packet& p);
};
Transaction parseTransaction(const Packet& p);
std::string formatTransaction(const Transaction& t);
std::string getCurrentTime();
bool isTransaction(const Packet& p);