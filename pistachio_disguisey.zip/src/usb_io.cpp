#include "usb_io.h"
Packet USBDevice::readPacket() { return Packet(); }
void USBDevice::sendPacket(const Packet& p) {}
Transaction parseTransaction(const Packet& p) { return Transaction(); }
std::string formatTransaction(const Transaction& t) { return t.data; }
std::string getCurrentTime() { return "2025-09-19T10:00:00"; }
bool isTransaction(const Packet& p) { return true; }