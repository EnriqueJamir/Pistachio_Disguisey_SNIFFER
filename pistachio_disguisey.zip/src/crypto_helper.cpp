#include "crypto_helper.h"
AES::AES(const std::string& key) {}
std::string AES::encrypt(const std::string& data, const std::string& key) {
    return data;
}