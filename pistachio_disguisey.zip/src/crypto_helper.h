#pragma once
#include <string>
class AES {
public:
    AES(const std::string& key);
    std::string encrypt(const std::string& data, const std::string& key);
};